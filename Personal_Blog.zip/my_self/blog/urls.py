from django.urls import path
from . import views

urlpatterns = [
    path("",views.start1,name="start1")
]
